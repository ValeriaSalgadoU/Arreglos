package mx.unam.fes.tienda;

public class Cliente {
    private int numero;
    private int tiempo;

    public Cliente(int numero, int tiempo) {
        this.numero = numero;
        this.tiempo = tiempo;
    }

    public int getNumero() {
        return numero;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    @Override
    public String toString() {
        return "Cliente " + numero + " | Tiempo: " + tiempo;
    }
}