package mx.unam.fes.inicio;

import java.util.Random;

import mx.unam.fes.tienda.Caja;
import mx.unam.fes.tienda.Cliente;
import mx.unam.fes.tienda.Lista;

public class Principal {

    public static void main(String[] args) {

        Random random = new Random();

        Lista <Cliente> fila = new Lista<>();

        Caja caja1 = new Caja(1);
        Caja caja2 = new Caja(2);
        Caja caja3 = new Caja(3);

        int numeroCliente = 1;

        for (int tiempo = 1; tiempo <= 20; tiempo++) {
            System.out.println("\n======================");
            System.out.println("TIEMPO: " + tiempo);
            System.out.println("======================");
            
            caja1.disminuirTiempo();
            caja2.disminuirTiempo();
            caja3.disminuirTiempo();

            if (caja1.getTiempo() == 0 && !fila.esVacia()) {
                Cliente c = fila.eliminarDeCabeza(); 
                caja1.agregarTiempo(c.getTiempo());
                System.out.println("Cliente " + c.getNumero() + " pasó de la FILA a la Caja 1");
            }
            if (caja2.getTiempo() == 0 && !fila.esVacia()) {
                Cliente c = fila.eliminarDeCabeza();
                caja2.agregarTiempo(c.getTiempo());
                System.out.println("Cliente " + c.getNumero() + " pasó de la FILA a la Caja 2");
            }
            if (caja3.getTiempo() == 0 && !fila.esVacia()) {
                Cliente c = fila.eliminarDeCabeza();
                caja3.agregarTiempo(c.getTiempo());
                System.out.println("Cliente " + c.getNumero() + " pasó de la FILA a la Caja 3");
            }

            int llegada = random.nextInt(100) + 1;
            if (llegada <= 50) {
                int duracion = random.nextInt(15) + 1;
                Cliente cliente = new Cliente(numeroCliente, duracion);
                System.out.println("Llegó: " + cliente);
                numeroCliente++;

                Caja menor = caja1;
                if (caja2.getTiempo() < menor.getTiempo()) {
                    menor = caja2;
                }
                if (caja3.getTiempo() < menor.getTiempo()) {
                    menor = caja3;
                }

                if (menor.getTiempo() == 0) {
                    menor.agregarTiempo(cliente.getTiempo());
                    System.out.println("Cliente asignado a Caja " + menor.getNumero());
                } else {
                    fila.agregarCola(cliente);
                    System.out.println("Todas las cajas ocupadas. Cliente " + cliente.getNumero() + " enviado a la fila.");
                }

            } else {
                System.out.println("No llegó cliente.");
            }

            System.out.println("\nCAJAS:");
            System.out.println(caja1);
            System.out.println(caja2);
            System.out.println(caja3);

            System.out.println("\nFILA DE ESPERA:");
            if (fila.esVacia()) {
                System.out.println("Vacía");
            } else {
                fila.imprimirTodo();
            }
        }
    }
}