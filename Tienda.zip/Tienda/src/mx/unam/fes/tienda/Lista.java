package mx.unam.fes.tienda;

public class Lista<E> {

    private Nodo<E> cabeza, cola;
    private int longitud = 0;

    public Lista() {
        cabeza = cola = null;
    }

    public boolean esVacia() {
        return cabeza == null;
    }

    public void agregarCabeza(E dato) {
        cabeza = new Nodo<E>(dato, cabeza);
        if (cola == null) {
            cola = cabeza;
        }
        longitud++;
    }

    public void agregarCola(E dato) {
        if (!esVacia()) {
            cola.setSiguiente(new Nodo<E>(dato));
            cola = cola.getSiguiente();
        } else {
            cola = cabeza = new Nodo<E>(dato);
        }
        longitud++;
    }

    public E eliminarDeCabeza() {
        E dato = null;
        if (!esVacia()) {
            dato = cabeza.getDato();
            if (cabeza == cola) {
                cabeza = cola = null;
            } else {
                cabeza = cabeza.getSiguiente();
            }
            longitud--;
        }
        return dato;
    }

    public int getLongitud() {
        return longitud;
    }

    public void imprimirTodo() {
        for (Nodo<E> temp = cabeza;
             temp != null;
             temp = temp.getSiguiente()) {

            System.out.println(temp.getDato());
        }
    }
}
