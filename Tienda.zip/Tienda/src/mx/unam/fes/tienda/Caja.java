package mx.unam.fes.tienda;

public class Caja {

    private int numero;
    private int tiempo;

    public Caja(int numero) {
        this.numero = numero;
        tiempo = 0;
    }

    public int getNumero() {
        return numero;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void agregarTiempo(int tiempo) {
        this.tiempo += tiempo;
    }

    public void disminuirTiempo() {

        if (tiempo > 0) {
            tiempo--;
        }
    }

    public boolean estaLibre() {
        return tiempo == 0;
    }

    @Override
    public String toString() {
        return "Caja " + numero + " | Tiempo: " + tiempo;
    }
}
