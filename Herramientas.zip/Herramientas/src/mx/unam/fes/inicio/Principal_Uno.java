package mx.unam.fes.inicio;
import java.util.Random;
import mx.unam.fes.estatico.Arreglo;
import mx.unam.fes.excepciones.IndiceFueraException;

public class Principal_Uno {
	public static void main(String[] args) {
		Arreglo<Integer> arrUno=new Arreglo<Integer>(100);
		Random r=new Random();
		try {
			while(!arrUno.vacio()) {
				arrUno.insertar(r.nextInt(101));
			}
			int mayor=-1;
			int segundoMayor=-1;
			long suma=0;
			int i;
			int num;
			for (i=0; i<arrUno.getLongitud();i++) {
				num=arrUno.recuperar(i);
				suma+=num;
				
				if (num>mayor) {
					segundoMayor=mayor;
					mayor=num;
				} else if(num>segundoMayor&&num!=mayor) {
					segundoMayor=num;
				}
			}
			
			double promedio=(suma/1000);
			
			System.out.println("Mayor: "+ mayor);
			System.out.println("Segundo mayor: "+ segundoMayor);
			System.out.println("Promedio: " + promedio);
			
			
			
		} catch (IndiceFueraException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}