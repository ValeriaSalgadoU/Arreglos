package mx.unam.fes.estatico;

import mx.unam.fes.excepciones.IndiceFueraException;
/**
 * Clase de estructura de datos estática mediante un arreglo
 * @param <E> El tipo de dato que almacena el arreglo
 */

public class Arreglo<E> {
	private int indice;
	private final Object[] arreglo;
	
	/**
	 * Constructor
	 * @param longitud Tamaño del arreglo
	 */
	
	public Arreglo(int longitud) {
		arreglo=new Object[longitud];
		indice=0;
	}
	
	public int getIndice() {
		return indice;
	}

	public Object[] getArreglo() {
		return arreglo;
	}
	
	public int getLongitud() {
		return getArreglo().length;
	}
	
	/**
	 * Insertar (x,L): Elemento x en lista L
	 * @param elemento Dato a insertar
	 * @throws IndiceFueraException Si el arreglo está lleno
	 */
	
	public void insertar(E elemento) throws IndiceFueraException {
		if(indice<arreglo.length) {
			arreglo[indice]=elemento;	
			indice++;
		}else {
			 throw new IndiceFueraException("Indice fuera del arreglo");
		}
	} 
	
	/**
	 * Localizar (x,l):Posición de elemento x en lista L
	 * @param elemento Elemento a buscar
	 * @return El índice, o -1 si no se encuentra
	 */
	
	public int localizar (E elemento) {
		for (int i=0;i<indice;i++) {
			if (arreglo [i].equals(elemento)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Recuperar(p,L): Devuelve el elemento x  de la posición p en la lista L
	 * @param indice Posición del elemento
	 * @return El elemento
	 * @throws IndiceFueraException Si el índice no es válido
	 */
	
	public E recuperar (int indice) throws IndiceFueraException{
		if (indice>=0 && indice<this.indice) {
			return (E) arreglo[indice];
		}else {
			throw new IndiceFueraException("Posición no válida");
		}
	}
	
	/**
	 * Suprime: Elimina el elemento de posición p y recorre elementos
	 * @param indice
	 * @throws IndiceFueraException
	 */
	
	public void suprime (int indice) throws IndiceFueraException{
		if (indice>=0 && indice<this.indice){
			for (int i=indice; i<this.indice-1;i++) {
				arreglo[i]=arreglo[i+1];
			}
			this.indice--;
			arreglo[this.indice]=null;
		}else {
			throw new IndiceFueraException("Posición inválida");
		}
	}
	
	/**
	 * Siguiente(p,L): Da la posición siguiente de la posición p en la lista L
	 * @param indice Posición actual
	 * @return Posición siguiente
	 * @throws IndiceFueraException Si no tiene elemento siguiente
	 */
	
	public E siguiente (int indice) throws IndiceFueraException{
		if (indice>=0 && indice<this.indice-1) {
			return (E) arreglo[indice+1];
		}else {
			throw new IndiceFueraException("Sin elemento siguiente");
		}
	}
	
	/**
	 * Anterior(p,L): Da la posición anterior de la posición p
	 * @param indice Posición actuañ
	 * @return Posición anterior
	 * @throws IndiceFueraException Si no tiene elemento anterior
	 */
	
	public E anterior (int indice) throws IndiceFueraException{
		if (indice>=0 && indice<this.indice-1) {
			return (E) arreglo[indice-1];
		}else {
			throw new IndiceFueraException("Sin elemento anterior");
		}
	}
	
	/**
	 * Método para saber sí está vacío
	 * @return true sí está vacío, false sí hay elementos
	 */
	
	public boolean vacio() {
		return indice == 0; 
	}
	
	/**
	 * Limpia los elementos de un arreglo
	 */
	
	public void limpiar() {
		for (int i=0;i<indice;i++) {
			arreglo[i]=null;
		}
		indice=0;
	}
	
	/**
	 * Devuelve el primer elemento del arreglo
	 * @return El primer elemento
	 * @throws IndiceFueraException Si está vacío
	 */
	
	public E primero() throws IndiceFueraException{
		if (indice>0) {
			return (E) arreglo[0];
		}else {
			throw new IndiceFueraException("No hay primero");
		}
	}
	
	/**
	 * Imprime elementos en el arreglo
	 */
	
	public void imprimir() {
		for(int i=0;i<indice;i++) {
			System.out.print(arreglo[i]+(i<indice-1?",":""));
		}
		System.out.println();
	}
}