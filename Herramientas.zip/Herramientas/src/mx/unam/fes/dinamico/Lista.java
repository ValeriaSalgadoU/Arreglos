package mx.unam.fes.dinamico;
/**
 * Clase de lista con cabeza y cola
 * @param <E> El tipo de dato que almacena la lista
 */

public class Lista<E> {
	private Nodo<E> cabeza, cola;
	private int longitud = 0;
	
	/**
	 * Constructor
	 */
	
	public Lista() {
		cabeza = cola = null;
	}

	/**
	 * Verifica si la lista está vacía
	 * @return true si es vacía, false si hay elementos
	 */
	
	public boolean esVacia() {
		return cabeza == null;
	}
	
	/**
	 * Agrega un nuevo elemento en la cabeza (inicio) de la lista
	 * @param dato Elemento a insertar
	 */
	
	public void agregarCabeza(E dato) {
		cabeza = new Nodo<E>(dato, cabeza);
		if (cola == null) {
			cola = cabeza;
		}
		longitud++;
	}
	
	/**
	 * Agrega un elemento a la cola (fin) dela lista
	 * @param dato Elemento a agregar
	 */

	public void agregarCola(E dato) {
		if (!esVacia()) {
			cola.setSiguiente(new Nodo<E>(dato));
			cola = cola.getSiguiente();
		} else {
			cola = cabeza = new Nodo<E>(dato);
		}
		longitud++;
	}
	
	/**
	 * 
	 * @return
	 */
	
	public Object eliminarDeCabeza() {
		Object dato = null;
		if (!esVacia()) {
			dato = cabeza.getDato();
			if (cabeza == cola) {
				cabeza = cola = null;
			} else {
				cabeza = cabeza.getSiguiente();
			}
			longitud--;
		}
		return dato;
	}
	
	/**
	 * Devuelve cantidad de elementos en lista
	 * @return Tamaño de la lista
	 */

	public int getLongitud() {
		return longitud;
	}
	
	/**
	 * Elimina y regresa el último elemento de la lista
	 * @return El  elemento eliminado sí hay, si no regresa null
	 */
	
	public E eliminarDeCola() {
		E dato = null;
		if (!esVacia()) {
			dato = cola.getDato();
			if (cabeza == cola) {
				cabeza = cola = null;
			} else {
				Nodo<E> temp;
				for (temp = cabeza; temp.getSiguiente() != cola; temp =temp.getSiguiente());
				cola = temp;
				cola.setSiguiente(null);
			}
			longitud--;
		}
		return dato;
	}
	
	/**
	 * Obtiene el elemento de una posición específica
	 * @param indice posición de elemento a recuperar
	 * @return Elemento indicado, si es que no existe null
	 */
	
	public E obtenerNodo(int indice) {
		Nodo<E> temp = cabeza;
		for (int contador = 0; contador < indice && temp != null; contador++, temp = temp.getSiguiente());
		if (temp != null) {
			return temp.getDato();
		} else {
			return null;
		}
	}

	/**
	 * Reemplaza eldato de un nodo específicp
	 * @param dato Nuevo dato a colocar
	 * @param indice La posición del nodo a modificar
	 * @return true si se modificó correctamente, false si no es así
	 */
	
	public boolean insertarEnIndice(E dato, int indice) {
		Nodo<E> temp = cabeza;
		for (int contador = 0; contador < indice && temp != null; contador++, temp = temp.getSiguiente())
			;
		if (temp != null) {
			temp.setDato(dato);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Imprime
	 */
	
	public void imprimir() {
		for (Nodo<E> temp = cabeza; temp != null; temp = temp.getSiguiente()) {
			System.out.println(temp.getDato() + " ");
		}
	}
	
	/**
	 *Busca y elimina la primera coincidencia en la lista
	 * @param dato El elemento a borrar
	 */

	public void borrar(E dato) {
		if (!esVacia()) {
			if (cabeza == cola && dato.equals(cabeza.getDato())) {
				cabeza = cola = null;
				longitud--;
			} else if (dato.equals(cabeza.getDato())) {
				cabeza = cabeza.getSiguiente();
				longitud--;
			} else {
				Nodo<E> predesor, tmp;
				for (predesor = cabeza, tmp = cabeza.getSiguiente();
						tmp != null && !tmp.getDato().equals(dato); predesor = predesor.getSiguiente(), tmp = tmp.getSiguiente());
				if (tmp != null) {
					predesor.setSiguiente(tmp.getSiguiente());
					if (tmp == cola) {
						cola = predesor;
					}
					longitud--;
				}
			}
		}
	}
	
	/**
	 *Elimina un elemento en posición específica
	 * @param indice Posición de elemento a eliminar
	 */
	
	public void borrarEnIndice(int indice) {
		if (!esVacia()) {
			if (cabeza == cola && indice == 0) {
				cabeza = cola = null;
				longitud--;
			} else if (indice == 0) {
				cabeza = cabeza.getSiguiente();
				longitud--;
			} else {
				Nodo<E> predesor, tmp;
				int contador = 1;
				for (predesor = cabeza, tmp = cabeza.getSiguiente(); contador < indice;
						predesor = predesor.getSiguiente(), tmp = tmp.getSiguiente(), contador++);
				if (tmp != null) {
					predesor.setSiguiente(tmp.getSiguiente());
					if (tmp == cola) {
						cola = predesor;
					}
					longitud--;
				}
			}
		}
	}
}
