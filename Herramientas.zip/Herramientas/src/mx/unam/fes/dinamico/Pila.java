package mx.unam.fes.dinamico;

/**
 * Implementación de Pila (LIFO)
 * @param <E> Tipo de dato almacenado en pila
 */

public class Pila<E> {
    private Lista<E> lista;

    /**
     * Constructor
     */
    
    public Pila() {
        lista = new Lista<E>();
    }
    
    /**
     * Inserta un elemento en la cabeza de la pila
     * @param dato
     */
   
    public void agregarCabeza(E dato) {
        lista.agregarCabeza(dato);
    }
    
    /**
     * Elimina y regresa el elemento en la cabeza de la pila
     * @return El elemento eliminado, o null
     */
   
    public E eliminarCabeza() {
    	if (lista.esVacia()) {
    		return null;
    	}
        return (E) lista.eliminarDeCabeza();
    }
    
    /**
     * Devuelve el elemento en la cabeza sin eliminar
     * @return Elemento en la cabeza o null
     */
    
    public E peek() {
    	if (lista.esVacia()) {
    		return null;
    	}
        return lista.obtenerNodo(0);
    }

    /**
     * Revisa si la pila está vacía
     * @return true si está vacia, false si tiene elementos
     */
    
    public boolean esVacia() {
        return lista.esVacia();
    }
    
    /**
     * Devulve cantidad de elementos en la pila
     * @return Tamaño de pila
     */

    public int getLongitud() {
        return lista.getLongitud();
    }

    /**
     * Imprime
     */
    
    public void imprimir() {
        lista.imprimir();
    }
}
