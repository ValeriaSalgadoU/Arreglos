package mx.unam.fes.dinamico;


/**
 * Lista Doblemente Enlazada genérica
 * Permite recorrer y modificar los elementos en ambas direcciones
 * 
 * @param <E> Tipo de dato almacenado
 */
public class ListaDoble<E> {
    private NodoDoble<E> cabeza, cola;
    private int longitud = 0;

    /**
     * Constructor 
     */
    public ListaDoble() {
        cabeza = cola = null;
    }

    /**
     * Verifica si la lista esta vacía
     * @return true si no hay elementos, false si hay
     */
    public boolean esVacia() {
        return cabeza == null;
    }

    /**
     * Agrega un nuevo elemento en la cabeza de la lista
     * @param dato elemento a insertar
     */
    public void agregarCabeza(E dato) {
        NodoDoble<E> nuevo = new NodoDoble<>(dato, cabeza, null);
        if (esVacia()) {
            cola = nuevo;
        } else {
            cabeza.setAnterior(nuevo);
        }
        cabeza = nuevo;
        longitud++;
    }

    /**
     * Agrega un nuevo elemento a la cola de la lista
     * @param dato elemento a insertar
     */
    public void agregarCola(E dato) {
        NodoDoble<E> nuevo = new NodoDoble<>(dato, null, cola);
        if (esVacia()) {
            cabeza = nuevo;
        } else {
            cola.setSiguiente(nuevo);
        }
        cola = nuevo;
        longitud++;
    }

    /**
     * Elimina y devuelve el primer elemento de la lista.
     * @return elemento eliminado, o null
     */
    public E eliminarDeCabeza() {
        if (esVacia()) return null;
        E dato = cabeza.getDato();
        
        if (cabeza == cola) {
            // Caso 1: Solo había un elemento en la lista
            cabeza = null;
            cola = null;
        } else {
            // Caso 2: Hay más de un elemento
            cabeza = cabeza.getSiguiente();
            if (cabeza != null) {
                cabeza.setAnterior(null);
            }
        }
        longitud--;
        return dato;
    }

    /**
     * Elimina y devuelve el último elemento de la lista
     * @return elemento eliminado, o null
     */
    public E eliminarDeCola() {
        if (esVacia()) return null;
        E dato = cola.getDato();
        
        if (cabeza == cola) {
            cabeza = null;
            cola = null;
        } else {
            cola = cola.getAnterior();
            if (cola != null) {
                cola.setSiguiente(null);
            }
        }
        longitud--;
        return dato;
    }

    /**
     * Imprime todos los elementos
     */
    public void imprimir() {
        for (NodoDoble<E> temp = cabeza; temp != null; temp = temp.getSiguiente()) {
            System.out.print(temp.getDato() + " ");
        }
        System.out.println();
    }
    
    /**
     * Devuelve la cantidad de elementos 
     * @return tamaño de la lista
     */
    public int getLongitud() {
        return longitud;
    }
}
