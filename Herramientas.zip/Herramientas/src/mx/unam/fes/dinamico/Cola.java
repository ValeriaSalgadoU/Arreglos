package mx.unam.fes.dinamico;

/**
 * Implementación de cola (FIFO)
 * @param <E> Tipo de dato almacenado
 */

public class Cola<E> {
    private Lista<E> lista;

    /**
     * Constructor
     */
    
    public Cola() {
        lista = new Lista<E>();
    }

    /**
     * Inserta elemento al final de la cola
     * @param dato Elemento a insertar
     */
  
    public void agregacola(E dato) {
        lista.agregarCola(dato);
    }

    /**
     * Elimina y devuelve el primer elemento de cola
     * @return El elemento retirado o null
     */
    
    public E eliminacola() {
    	if (lista.esVacia()) {
    		return null;
    	}
        return (E) lista.eliminarDeCabeza();
    }
    
    /**
     * Devuleve el primer elemento de la cola sin eliminar
     * @return Primer elemento o null
     */

    public E primerElemento() {
    	if (lista.esVacia()) {
    		return null;
    	}
        return lista.obtenerNodo(0);
    }

    /**
     * Verifica si la cola está vacía
     * @return true si es vacia,false si hay elementos
     */
    
    public boolean esVacia() {
        return lista.esVacia();
    }

    /**
     * Devulve la cal¿ntidad de elementos en la cola
     * @return Tamaño de la cola
     */
    
    public int getLongitud() {
        return lista.getLongitud();
    }

    /**
     * Imprime
     */
    
    public void imprimir() {
        lista.imprimir();
    }
}
