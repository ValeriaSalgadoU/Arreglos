package mx.unam.fes.dinamico;

/**
 * Clase que representa un nodo para lista doblemente enlazada
 * @param <E> Tipo de dato almacenado
 */

public class NodoDoble<E> {
    private E dato;
    private NodoDoble<E> siguiente;
    private NodoDoble<E> anterior;
    
    /**
     * Constructor que inicializa el nodo con un dato y sin enlaces
     * @param dato Valor a almacenar en el nodo
     */
    
    public NodoDoble(E dato) {
        this(dato, null, null);
    }
    
    /**
     * Constructor que inicializa nodo con enlaces específicos
     * @param dato Valor a almacenar
     * @param anterior Referencia a nodo siguiete
     * @param siguiente Referencia a  a nodo anterior
     */

    public NodoDoble(E dato, NodoDoble<E> anterior, NodoDoble<E> siguiente) {
        this.dato = dato;
        this.anterior = anterior;
        this.siguiente = siguiente;
    }
    
    /**
     * @return dato en el nodo
     */
    public E getDato() {
        return dato;
    }
    
    /**
     * @return nuevo dato a almacenar
     */
    public void setDato(E dato) {
        this.dato = dato;
    }
    
    /**
     * @return nodo siguiente
     */
    public NodoDoble<E> getSiguiente() {
        return siguiente;
    }

    /**
     * @param siguiente nuevo nodo siguiente a enlazar
     */
    public void setSiguiente(NodoDoble<E> siguiente) {
        this.siguiente = siguiente;
    }

    /**
     * @return nodo anterior
     */
    public NodoDoble<E> getAnterior() {
        return anterior;
    }

    /**
     * @param anterior el nuevo nodo anterior a enlazar
     */
    public void setAnterior(NodoDoble<E> anterior) {
        this.anterior = anterior;
    }
}
