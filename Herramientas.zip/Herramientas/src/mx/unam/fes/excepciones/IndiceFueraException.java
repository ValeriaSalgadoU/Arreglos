package mx.unam.fes.excepciones;

public class IndiceFueraException extends Exception{

	private static final long serialVersionUID = 1L;

	public IndiceFueraException(String msg) {
		super(msg);
	}	

}
